

    /*
    * Artist
    * Title
    * Album
    * Release Year
    * Duration
    * contributing Artist
    * Writer
    * Producer
    * Editor*/

    var Artists: String = "Mali Music" //String
    var Title: String = "The Job Experience" //String
    var Album: String = "Yahweh" //String
    var Release_Year: Int = 2005 //Integer
    var Release_Day: Int =  16 //Integer
    var Release_Month: Int = 11 //Integer
    var Release_Date: String = "$Release_Year/$Release_Month/$Release_Day" //String concatenation

    var Song_Duration: Double = 11.3 //Double
    var Contributing_Artist: String = "Passion" //Double

    var File_Size: Long = 134521 //file size in Long
    val actual_file_size: String = "$File_Size KB" //printed in String

    var Genre: String = "Gospel" //String

    var Star_Rating = 5 //System automatically detects the assigned variable's type to be(declared as) an Integer
    val Rating = "$Star_Rating Stars" //printed in String
    
    //all the data in stored in the final value 'meta_data'
    //i use '\n' to print another value on another line

    val meta_data = "Artist: $Artists\n" +
            "Title: $Title\n" +
            "Album: $Album\n" +
            "Release Data: $Release_Date\n" +
            "Song Duration: $Song_Duration\n" +
            "Contributing Artist: $Contributing_Artist\n" +
            "File Size: $actual_file_size\n" +
            "Genre: $Genre\n" +
            "Rating: $Rating"

    Log.d("Tag", meta_data) //to display the value stored in 'meta_data'






